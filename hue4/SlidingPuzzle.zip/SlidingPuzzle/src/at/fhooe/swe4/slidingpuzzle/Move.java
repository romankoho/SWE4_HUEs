package at.fhooe.swe4.slidingpuzzle;

public enum Move { LEFT, RIGHT, UP, DOWN };
