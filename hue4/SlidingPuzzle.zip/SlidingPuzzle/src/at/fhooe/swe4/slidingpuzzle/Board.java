package at.fhooe.swe4.slidingpuzzle;

import java.util.List;

public class Board implements Comparable<Board> {
  
  // Board mit Zielkonfiguration initialisieren.
  public Board(int size) {
    
  }

  // Überprüfen, ob dieses Board und das Board other dieselbe Konfiguration
  // aufweisen.
  public boolean equals(Object other) {
    return false;
  }

  // <1, wenn dieses Board kleiner als other ist.
  // 0, wenn beide Boards gleich sind
  // >1, wenn dieses Board größer als other ist.
  public int compareTo(Board other) {
    return 0;
  }

  // Gibt die Nummer der Kachel an der Stelle (i,j) zurück,
  // Indizes beginnen bei 1. (1,1) ist somit die linke obere Ecke.
  // Wirft die Laufzeitausnahme InvalidBoardIndexException.
  public int getTile(int i, int j) {
    return 0;
  }

  // Setzt die Kachelnummer an der Stelle (i,j) zurück. Wirft die
  // Laufzeitausnahmen
  // InvalidBoardIndexException und InvalidTileNumberException
  public void setTile(int i, int j, int number) {
    
  }

  // Setzt die Position der leeren Kachel auf (i,j)
  // Entsprechende Kachel wird auf 0 gesetzt.
  // Wirft InvalidBoardIndexException.
  public void setEmptyTile(int i, int j) {
    
  }

  // Zeilenindex der leeren Kachel
  public int getEmptyTileRow() {
    return 0;
  }

  // Gibt Spaltenindex der leeren Kachel zurück.
  public int getEmptyTileColumn() {
    return 0;
  }

  // Gibt Anzahl der Zeilen (= Anzahl der Spalten) des Boards zurück.
  public int size() {
    return 0;
  }

  // Überprüft, ob Position der Kacheln konsistent ist.
  public boolean isValid() {
    return false;
  }

  // Macht eine tiefe Kopie des Boards.
  // Vorsicht: Referenztypen müssen neu allokiert und anschließend deren Inhalt
  // kopiert werden.
  public Board copy() {
    return null;
  }

  // Erzeugt eine zufällige lösbare Konfiguration des Boards, indem auf die
  // bestehende
  // Konfiguration eine Reihe zufälliger Verschiebeoperationen angewandt wird.
  public void shuffle() {
    
  }

  // Verschiebt leere Kachel auf neue Position (row, col).
  // throws IllegalMoveException
  public void move(int row, int col) {
    
  }

  // Verschiebt leere Kachel nach links. Wirft Laufzeitausnahme
  // IllegalMoveException.
  public void moveLeft() {
    
  }

  // Verschiebt leere Kachel nach rechts. Wirft IllegalMoveException.
  public void moveRight() {
    
  }

  // Verschiebt leere Kachel nach oben. Wirft IllegalMoveException.
  public void moveUp() {
    
  }

  // Verschiebt leere Kachel nach unten. Wirft IllegalMoveException.
  public void moveDown() {
    
  }

  // Führt eine Sequenz an Verschiebeoperationen durch. Wirft
  // IllegalMoveException.
  public void makeMoves(List<Move> moves) {
    
  }
}
