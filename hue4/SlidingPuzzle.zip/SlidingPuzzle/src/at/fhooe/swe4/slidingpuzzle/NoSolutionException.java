package at.fhooe.swe4.slidingpuzzle;

public class NoSolutionException extends RuntimeException {

  private static final long serialVersionUID = 9200158723486279638L;

}
