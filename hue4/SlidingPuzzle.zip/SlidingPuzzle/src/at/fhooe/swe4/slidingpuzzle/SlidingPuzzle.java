package at.fhooe.swe4.slidingpuzzle;

import java.util.List;

public class SlidingPuzzle {

    // Berechnet die Zugfolge, welche die gegebene Board-Konfiguration in die
    // Ziel-Konfiguration überführt.
    // Wirft NoSolutionException (Checked Exception), falls es eine keine derartige 
    // Zugfolge gibt.
    public static List<Move> solve(Board board) {
      return null;
    }

    // Gibt die Folge von Board-Konfigurationen auf der Konsole aus, die sich durch
    // Anwenden der Zugfolge moves auf die Ausgangskonfiguration board ergibt.
    public static void printMoves(Board board, List<Move> moves) {
    }
}
