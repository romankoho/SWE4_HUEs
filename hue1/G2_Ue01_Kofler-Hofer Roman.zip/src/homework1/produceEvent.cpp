//file: produceEvent.cpp
#include "produceEvent.h"

produceEvent::produceEvent(int time, Simulation* ownerSimulation, int numberProducts) : 
		Event(time, ownerSimulation), m_numberProducts(numberProducts) {}

void produceEvent::executeEvent ()
{
		MarketSimulation* mySim = dynamic_cast<MarketSimulation*>(m_ownerSimulation);

		std::cout<< std::endl << "## Processing next event ##" << std::endl;

		if((mySim->getCurBufferSize() + m_numberProducts) > mySim->getBufferCapacity ()) {

			//make buffer full
			int remainingProducts = m_numberProducts - (mySim->getBufferCapacity() - mySim->getCurBufferSize());
			std::cout << "Buffer too small. Only " << mySim->getBufferCapacity()-mySim->getCurBufferSize() 
								<< " pieces will be added to buffer" << std::endl;

			mySim->setBufferSize(mySim->getBufferCapacity());
			std::cout << "For remaining " << remainingProducts << " pieces new production event in " 
								<< m_time+mySim->getWaitingTime() << " is queued" << std::endl << std::endl;

			//new event for remaining production size
			produceEvent* delayedEvent = new produceEvent(m_time + mySim->getWaitingTime(), m_ownerSimulation, remainingProducts);
			m_ownerSimulation->addEvent(delayedEvent);
		}
		else {
			std::cout << "Everything ok" << std::endl << std::endl;
			mySim->setBufferSize(m_numberProducts+mySim->getCurBufferSize());
		}

}

void produceEvent::printEvent ()
{
	std::cout << "Production event at t=" << m_time << " | producing: " << m_numberProducts << " pieces" << std::endl;
}
