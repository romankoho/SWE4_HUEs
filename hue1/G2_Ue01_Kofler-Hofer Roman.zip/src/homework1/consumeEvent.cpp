//file: consumeEvent.cpp
#include "consumeEvent.h"

consumeEvent::consumeEvent (int time, Simulation* ownerSimulation, int numberProducts) : 
	Event(time, ownerSimulation), m_numberProducts(numberProducts) {}

void consumeEvent::executeEvent ()
{
	MarketSimulation* mySim = dynamic_cast<MarketSimulation*>(m_ownerSimulation);
	
	std::cout << std::endl << "## Processing next event ##" << std::endl;

	if(mySim->getCurBufferSize () - m_numberProducts > 0) {			//enough products in buffer to consume
		std::cout << "Everything ok" << std::endl << std::endl;
		mySim->setBufferSize(mySim->getCurBufferSize() - m_numberProducts);
		mySim->setConsumedProducts(mySim->getConsumedProducts()+m_numberProducts);
	}
	else {		//wait, register consumption event for later again
		
		//let consumer consum remaining products from buffer
		mySim->setConsumedProducts(mySim->getConsumedProducts()+mySim->getCurBufferSize());


		//create new event for remaining prodcuts from this event
		int remainingProducts = m_numberProducts - mySim->getCurBufferSize();
		std::cout << "Buffer too small. Only " << mySim->getCurBufferSize() << " pieces can be consumed" << std::endl;
		
		mySim->setBufferSize(0);
		std::cout << "For remaining " << remainingProducts << " pieces new consumption event in " 
							<<  mySim->getWaitingTime() + mySim->getCurrentTime() << " is queued" << std::endl << std::endl;

		consumeEvent* delayedEvent = new consumeEvent(m_time + mySim->getWaitingTime(), m_ownerSimulation, remainingProducts);
		m_ownerSimulation->addEvent(delayedEvent);
	}
}

void consumeEvent::printEvent ()
{
	std::cout << "Consume event at t=" << m_time << " | consuming: " << m_numberProducts << " pieces" << std::endl;
}