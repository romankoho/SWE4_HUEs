//file: MarketSimulation.h

#pragma once
#include "Simulation.h"
#include "Event.h"
#include "produceEvent.h"
#include "consumeEvent.h"
#include <iostream>

class MarketSimulation: public Simulation
{

	private:
		int m_bufferCapacity;
		int m_curBufferSize{0};
		int m_consumedProducts{0};
		int m_endSimulationSum{100};
		int m_waitingTime;										//time consumer/producer has to wait when buffer is empty/full

	public:
		MarketSimulation(int bufferCapacity, int waitingTime, int endSimulationSum=100, int maxIterations=1000);

		void randomInitSimulation(int nEvents, int maxEventTime=500, int maxEventNrPieces=50);

		int getBufferCapacity() {return m_bufferCapacity;}
		int getCurBufferSize() {return m_curBufferSize;}
		int getConsumedProducts() {return m_consumedProducts;}
		int getWaitingTime() {return m_waitingTime;}

		void setBufferSize(int v) {m_curBufferSize = v;}
		void setConsumedProducts(int v) {m_consumedProducts = v;}

		virtual bool hasEnded() override;
		virtual void printSimulation() override;
};

