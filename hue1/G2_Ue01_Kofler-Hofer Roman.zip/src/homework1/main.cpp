//file: main.cpp
#include <set>
#include <iterator>
#include <iostream>
#include "Simulation.h"
#include "produceEvent.h"
#include "consumeEvent.h"

using namespace std;

void test_simulation_creation () {
	MarketSimulation* mySimulation = new MarketSimulation(70,50,100);			//parameter: bufferCapacity, waitingTime, end condition
	mySimulation->randomInitSimulation(10);
	cout << endl<< "###################################" << endl;
	
	//output of queue
	cout << endl << "~~~~Structure of priority queue~~~~" << endl;
	mySimulation->outputAndDestroyQueue();

	delete mySimulation;

}

void testStep () {
	MarketSimulation* mySimulation = new MarketSimulation(100,50,100);	//parameter: bufferCapacity, waitingTime, end condition
	
	cout << "Simulation parameters: BufferCapacity = 100, waiting time = 50" << endl;
	mySimulation->randomInitSimulation(10);
	cout << endl<< "###################################" << endl;

	for(int i = 0; i < 10; i++) {
		cout << "Status of simulation at t=" << mySimulation->getCurrentTime() << endl;
		mySimulation->printSimulation(); cout << endl;
		mySimulation->step();
	}

	delete mySimulation;
}

void testSimulation () {
	int bufferCapacity = 100;			//max 100 pieces can be in the buffer
	int waitingTime = 50;					//if an event cannot be completed it is rescheduled for t+50
	int endCondition = 50;				//once consumers got 50 pieces simulation is ended
	
	cout << "Simulation parameters:" << endl;
	cout << " - Buffer capacity = " << bufferCapacity << endl;
	cout << " - Waiting time = " << waitingTime << endl;
	cout << " - End condition = " << endCondition << endl << endl;

	MarketSimulation* mySimulation = new MarketSimulation(bufferCapacity, waitingTime, endCondition);	//parameter: bufferCapacity, waitingTime, end condition
	mySimulation->randomInitSimulation(10);

	cout << endl<< "###################################" << endl;

	mySimulation->runSimulation();
	delete mySimulation;
}

int main () {
	//test_simulation_creation();
	//testStep();
	testSimulation();

	return 0;
}
