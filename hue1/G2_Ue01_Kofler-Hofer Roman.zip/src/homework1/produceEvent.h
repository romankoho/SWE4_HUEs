//file: produceEvent.h

#pragma once
#include "Event.h"
#include "MarketSimulation.h"


class produceEvent : public Event
{
	private:
		int m_numberProducts;

	public:
		produceEvent(int time, Simulation* ownerSimulation, int numberProducts);
		void executeEvent() override;
		void printEvent() override;
};

