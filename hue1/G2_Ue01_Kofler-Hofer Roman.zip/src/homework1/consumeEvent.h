//file consumeEvent.h
#pragma once
#include "Event.h"
#include "MarketSimulation.h"

class consumeEvent: public Event
{
	private:
		int m_numberProducts;

	public:
		consumeEvent(int time, Simulation* ownerSimulation, int numberProducts);
		void executeEvent() override;

		void printEvent() override;
};

