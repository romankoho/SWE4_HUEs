//file: Event.cpp

#pragma once
#include "Event.h"

void Event::printEvent () {
	std::cout << "event at t= " << m_time;
}