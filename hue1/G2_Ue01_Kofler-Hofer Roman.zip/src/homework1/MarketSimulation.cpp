//file MarketSimulation.cpp

#pragma once
#include "MarketSimulation.h"

MarketSimulation::MarketSimulation(int bufferCapacity, int waitingTime, int endSimulationSum, int maxIterations) : 
	Simulation(maxIterations), m_bufferCapacity(bufferCapacity),
						 m_waitingTime(waitingTime), m_endSimulationSum(endSimulationSum) {}

void MarketSimulation::randomInitSimulation (int nEvents, int maxEventTime, int maxEventNrPieces)
{
	std::cout << "~~~~Simulation randomly initialised with the following events~~~~" << std::endl;
		for(int i = 0; i < nEvents; i++) {
			int randEvent = randomNumWithin(1,2);
			int randTime = randomNumWithin(1, maxEventTime);
			int randAmount = randomNumWithin(1, maxEventNrPieces);

			if(randEvent == 1) {
				addEvent(new produceEvent(randTime, this, randAmount));
				std::cout << "Production event at time:  " << randTime << " | amount: " << randAmount << std::endl;
			}
			else {
				addEvent(new consumeEvent(randTime, this, randAmount));
				std::cout << "Consumption event at time:  " << randTime << " | amount: " << randAmount << std::endl;
			}
		}
}

bool MarketSimulation::hasEnded () {
	return m_consumedProducts >= m_endSimulationSum;
}

void MarketSimulation::printSimulation ()
{
	std::cout << "Current time: " << m_currentTime << std::endl;
	std::cout << "Current buffer size: " << m_curBufferSize << std::endl;
	std::cout << "Already consumed products: " << m_consumedProducts << std::endl;

	std::cout << "Events queued: " << m_events.size() << std::endl;
	
	std::cout << "Next event: ";
	if(!m_events.empty()) { 
		Event* nextEvent = m_events.top();
		nextEvent->printEvent();
	}
	else {
		std::cout << "no more events queued" << std::endl;
	}
}
