//file: Event.h
#pragma once
#include <iostream>
#include "utils.h"
class Simulation;

class Event
{
	protected:
		int m_time;
		Simulation* m_ownerSimulation;

	public:
		explicit Event(int t, Simulation* ownerSimulation) : m_time(t), m_ownerSimulation(ownerSimulation) {}; 
		virtual void executeEvent() = 0;

		int getEventTime() {return m_time;}
		virtual void printEvent();	
};

