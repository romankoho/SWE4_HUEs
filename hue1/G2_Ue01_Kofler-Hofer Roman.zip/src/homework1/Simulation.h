//file: Simulation.h

#pragma once
#include <queue>
#include <vector>
#include <functional>
#include "Event.h"

class Event;

class Simulation
{

	struct CustomComparator {
		bool operator()(Event* e1, Event* e2) {
			return e1->getEventTime() > e2->getEventTime();
		}
	};

	protected:
		std::priority_queue<Event*, std::vector<Event*>, CustomComparator> m_events;
		
		int m_currentTime{0};
		int m_maxIterations;

	public:
		Simulation(int maxIterations=1000);
		Simulation(const Simulation& mySim) = delete;
		Simulation& operator= (const Simulation& mySim) = delete;

		virtual ~Simulation();

		int getCurrentTime() {return m_currentTime;}
		int setCurrenttime(int t) {m_currentTime = t;}

		virtual void runSimulation();
		virtual bool hasEnded() = 0;
		void step();
		void addEvent (Event* e);

		virtual void printSimulation();

		//for debugging / testing
		void outputAndDestroyQueue();
};
