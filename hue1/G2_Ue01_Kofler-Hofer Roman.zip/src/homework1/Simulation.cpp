//file Simulation.cpp

#pragma once
#include "Simulation.h"

Simulation::Simulation (int maxIterations) : m_currentTime{}, m_events{}, m_maxIterations(maxIterations) {}

Simulation::~Simulation ()
{
	while(!m_events.empty ()) {
		m_events.pop();
	}
}

void Simulation::step ()
{
	if(!m_events.empty ()) {
		Event* nextEvent = m_events.top();
		m_events.pop();
		m_currentTime = nextEvent->getEventTime();
		nextEvent->executeEvent();
	}
}

void Simulation::runSimulation ()
{
	int i = 0;
	while(!m_events.empty() && !hasEnded() && i < m_maxIterations) {
		
		std::cout << "Status of simulation at t=" << m_currentTime << std::endl;
		printSimulation();
		
		Event* currEvent = m_events.top();
		m_events.pop();
		m_currentTime = currEvent->getEventTime();
		currEvent->executeEvent();
		i++;
	}

	std::cout << "Result of simulation:" << std::endl;
	std::cout << " - Reason for end of simulation: ";
	if(m_events.empty ()) {
		std::cout << "no more events in queue" << std::endl;
	}
	else if(i >= m_maxIterations) {
		std::cout << "no result in less than " << m_maxIterations << " steps" << std::endl;
	}
	else {
		std::cout << "end condition fulfilled" << std::endl;
	}
	std::cout << " - Simulation steps: " << i << std::endl;
}

void Simulation::addEvent (Event* e)
{
	m_events.push(e);
}

void Simulation::printSimulation ()
{
	std::cout << "Current time: " << m_currentTime << std::endl;
	std::cout  << "Events queued: " << m_events.size() << std::endl;
	
	std::cout  << "Next event: ";
	if(!m_events.empty()) { 
		Event* nextEvent = m_events.top();
		nextEvent->printEvent();
	}
	else {
		std::cout  << "no more events queued" << std::endl;
	}
}

void Simulation::outputAndDestroyQueue ()
{
	while(!m_events.empty ()) {
		Event* nextEvent = m_events.top();
		nextEvent->printEvent();
		m_events.pop();
	}
}