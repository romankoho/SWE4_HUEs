#include "skip_set.h"
#include "container_test_kit.h"
#include <iostream>
#include <set>
#include <random>

using std::cout;
using std::endl;

#define DEBUG(X) std::cout << (#X) << " -> " << (X) << std::endl
#define LOG(X) std::cout << (#X) << std::endl; (X)

void testInsert () {

	cout << endl << "~~~~~~~~~testInsert~~~~~~~~~" << endl;
	skip_set<int>* mySet = new skip_set<int>(0.5);

	DEBUG(mySet->size());
	mySet->insert(5);
	mySet->insert(67);
	mySet->insert(8);
	mySet->insert(10);
	DEBUG(mySet->size());

	cout << *mySet;
	delete mySet;
}

void testFind () {

	cout << endl << "~~~~~~~~~testFind~~~~~~~~~" << endl;
	skip_set<int>* mySet = new skip_set<int>(0.5);
	cout << boolalpha;

	DEBUG(mySet->size());
	DEBUG(mySet->find(10));

	mySet->insert(5);
	mySet->insert(67);
	mySet->insert(8);
	mySet->insert(10);
	
	cout << *mySet;

	DEBUG(mySet->find(10));
	DEBUG(mySet->find(3));
	DEBUG(mySet->find(67));
	DEBUG(mySet->find(5));
	DEBUG(mySet->find(8));

	delete mySet;
}

void testErase () {
	cout << endl << "~~~~~~~~~testErase~~~~~~~~~" << endl;
	skip_set<int>* mySet = new skip_set<int>(0.5);
	
	DEBUG(mySet->size());
	DEBUG(mySet->erase(8));

	mySet->insert(5);
	mySet->insert(67);
	mySet->insert(8);
	mySet->insert(10);

	DEBUG(mySet->erase(8));
	cout << *mySet;

	DEBUG(mySet->erase(5));
	DEBUG(mySet->erase(67));
	DEBUG(mySet->erase(8));
	DEBUG(mySet->erase(10));
	cout << *mySet;
	DEBUG(mySet->size());

	delete mySet;
}

int main () {
	srand(time	(0));
	testInsert();
	testFind();
	testErase();

	container_test_kit<set<int>> setTest{"set"};
	//setTest.insertPerformance();

	container_test_kit<skip_set<int>> skipSetTest{"skipSet"};
	//skipSetTest.insertPerformance();

	return 0;
}