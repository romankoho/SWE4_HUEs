#pragma once
#include "utils.h"
#include <chrono>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iterator>
#include <algorithm>

using namespace std::chrono;
using namespace std;

template <typename T>
class container_test_kit
{
	using container_type = T;

	private:
		container_type data;
		std::string m_type;

	public:
		container_test_kit(std::string type) : m_type(type), data{} {}

		void insertPerformance() {
			
			//prepare random (unique) numbers that will be inserted afterwards
			int countRandomNumbers = 2000000;
			int* randomNumbersArray = new int[countRandomNumbers];
			for (int i = 0; i < countRandomNumbers; i++) {
				randomNumbersArray[i] = i;
			}
			shuffle(randomNumbersArray, randomNumbersArray + countRandomNumbers, default_random_engine(rand()));

			//test is 5 times repeated (average will be used)
			int repetitions = 5;

			//time is always measured for 10k inserts
			int steps = 10000;

			//until 1.5 Mio inserted values are reached
			int insertedValues = 1500000;

			//data structur where time for each 10k inserts per repetition is saved
			multimap <int, double> measuredValues;

			for (int i = 0; i < repetitions; i++) {
				while (data.size() < insertedValues) {
					size_t currentSize = data.size();

					auto start = high_resolution_clock::now();
					for (int insertCalls = 0; insertCalls < steps; insertCalls++) {
						data.insert(randomNumbersArray[currentSize+insertCalls]);
					}
					auto end = high_resolution_clock::now();
					duration<double, std::milli> timePassed = end - start;
					//cout << "measured time starting at: " << currentSize << " = " << timePassed.count() << endl;				
					measuredValues.insert(make_pair(currentSize, timePassed.count()));
				}

				data.clear();
			}

			//prepare output files
			std::string fileName;
			if (m_type == "set") {
				fileName = "set_insert_performanceV2.txt";
			}
			else if (m_type == "skipSet") {
				fileName = "skipSet_insert_performanceV2.txt";
			}

			std::ofstream outfile{ fileName };
			outfile << "size of dataStructure (before inserting 10k elements); milliseconds" << std::endl;

			//sum up values for each key (0, 10k, 20k, 30,...) and calculate average
			for (int key = 0; key < insertedValues; key+=steps) {
				int sum = 0;
				double avg = 0;
				for (auto it = measuredValues.begin(); it != measuredValues.end(); it++) {
					if (it->first == key) {
						sum += it->second;
					}
				}

				avg = (double)sum / repetitions;

				outfile << key << ";";
				outfile << avg << std::endl;
			}

			outfile.close();
			delete[] randomNumbersArray;
		}
};

