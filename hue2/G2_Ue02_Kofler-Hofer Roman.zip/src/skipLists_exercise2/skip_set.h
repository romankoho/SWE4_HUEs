#pragma once
#include "utils.h"
#include <iostream>

using namespace std;


template<typename T, const int MAXLEVEL=32>
class skip_set
{
	private:
	
			class node
			{
				public:
					T m_value;

					//array which contains shared pointers of type node*
					node* *m_forwardArray;

					node(T val, int level) : m_value(val), m_forwardArray(new node*[level+1]{}) {}

					~node () {
						delete[] m_forwardArray;
						//std::cout << "destructor : " << m_value << std::endl;
					}
			};

		node* m_head;
		int m_level{0};
		double m_p;
		int m_size{0};

		node* newNode (T val, int level) {
			node* n = new node(val, level);
			return n;
		}

		int randomLevel () {

			int newLevel = 0;
			//float random = (float)rand()/RAND_MAX;
			double random = randomDoubleWithin(0, 0.99);

			while(random < m_p && newLevel < MAXLEVEL) {
				newLevel += 1;
				//random = (float)rand()/RAND_MAX;
				random = randomDoubleWithin(0, 0.99);
			}

			return newLevel;

		}

	
	public:
		
		//p... probability that nodes with level-i pointers also have level i+1 pointers
		//value must be >= x < 1
		skip_set(double p=0.5) : m_p(p), m_head(new node(T{}, MAXLEVEL)) { }

		~skip_set () {
			clear();
		}

		void clear() {
			node* n = m_head->m_forwardArray[0];
			node* succ = nullptr;

			while (n != nullptr) {
				succ = n->m_forwardArray[0];
				delete n;
				n = succ;
				m_size--;
			}

			for (int i = 0; i <= m_level; i++) {
				m_head->m_forwardArray[i] = nullptr;
			}
		}

		int size() const {return m_size;}
		
		bool find (T value) {
			node* x = m_head;

			for(int i = m_level; i >= 0; i--) {
				
				while(x->m_forwardArray[i] != nullptr && x->m_forwardArray[i]->m_value < value) {
					x = x->m_forwardArray[i];
				}
			}

			x = x->m_forwardArray[0];
			return x != nullptr && x->m_value == value;
		}

		void insert (T value) {
			node* x = m_head;			
			node* update[MAXLEVEL+1]{nullptr};

			for(int i = m_level; i >= 0; i--) {
				while(x->m_forwardArray[i] != nullptr && x->m_forwardArray[i]->m_value < value) {
							x = x->m_forwardArray[i];
				}
				update[i] = x;
			}

			x = x->m_forwardArray[0];

			if (x == nullptr || x->m_value != value) 
			{
				int new_level = randomLevel();

				if(new_level > m_level) {
					for (int i = m_level+1; i <= new_level; i++)	
					{
						update[i] = m_head;
					 }
						m_level = new_level;
					}

					node* insertedNode = newNode(value, new_level);

					for(int i = 0; i <= new_level; i++) {
						insertedNode->m_forwardArray[i] = update[i]->m_forwardArray[i];
						update[i]->m_forwardArray[i] = insertedNode;
					}

				m_size++;
				//cout << "Inserted value " << value << endl;
			}
		}
		
		bool erase (T value) {
			node* x = m_head;
			node* update[MAXLEVEL+1]{nullptr};

			for(int i = m_level; i >= 0; i--) {
				while(x->m_forwardArray[i] != nullptr && x->m_forwardArray[i]->m_value < value) {
					x = x->m_forwardArray[i];
				}
				update[i] = x;
			}
			x = x->m_forwardArray[0];

			if(x != nullptr && x->m_value == value) {
				for(int i = 0; i <= m_level; i++) {
					if(update[i]->m_forwardArray[i] != x) 
						break;

					update[i]->m_forwardArray[i] = x->m_forwardArray[i];
				}
				delete x;
				m_size--;
				while(m_level > 0 && m_head->m_forwardArray[m_level] == nullptr) {
					m_level--;
				}

				return true;
			}
			else {
				return false;
			}
		}
		
		friend std::ostream& operator << (std::ostream& os, const skip_set& s) {
			for(int i = 0; i <= s.m_level; i++) {
				node* current = s.m_head->m_forwardArray[i];
				os << "Level " << i << ": ";
				while(current != nullptr) {
					os << current->m_value << " ";
					current = current->m_forwardArray[i];
				}
				os << endl;
			}
			return os;
		}
};
