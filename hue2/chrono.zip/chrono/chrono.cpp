#include <chrono>
#include <iostream>

using namespace std;
using namespace std::chrono;

long fib(unsigned int n) {
  if (n < 2) return 1;
  return fib(n-1) + fib(n-2);
}

int main() {
  auto start = high_resolution_clock::now();
  cout << fib(42) << endl;
  auto end = high_resolution_clock::now();
  duration<double> diff = end-start;
  cout << "time: " << duration_cast<milliseconds>(diff).count() << endl;
  return 0;
}